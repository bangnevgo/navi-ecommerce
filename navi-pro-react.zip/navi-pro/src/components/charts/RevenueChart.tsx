'use client';
import { useEffect, useRef } from 'react';
import { useDashboardStore } from '@/store/useDashboardStore';
import { generateChartData } from '@/utils/format';
import { PLATFORM_COLORS, revenueChartOptions } from '@/utils/chartConfig';

export function RevenueChart() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);
  const { currentPeriod, data } = useDashboardStore();

  useEffect(() => {
    if (typeof window === 'undefined') return;
    import('chart.js/auto').then((ChartModule) => {
      const Chart = ChartModule.default;
      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx) return;

      if (chartRef.current) { chartRef.current.destroy(); }

      const days = data.days;
      const labels = Array.from({ length: days }, (_, i) => {
        const d = new Date();
        d.setDate(d.getDate() - (days - i - 1));
        if (days <= 14) return d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' });
        if (days <= 30) return i % 5 === 0 ? d.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }) : '';
        return i % 30 === 0 ? d.toLocaleDateString('id-ID', { month: 'short' }) : '';
      });

      const makeGradient = (color: string) => {
        const g = ctx.createLinearGradient(0, 0, 0, 280);
        g.addColorStop(0, color.replace('1)', '0.5)').replace(')', ', 0.5)'));
        g.addColorStop(1, color.replace('1)', '0.02)').replace(')', ', 0.02)'));
        return g;
      };

      chartRef.current = new Chart(ctx, {
        type: 'bar',
        data: {
          labels,
          datasets: [
            { label: 'Tokopedia', data: generateChartData(days), backgroundColor: makeGradient('rgba(16,217,160,1)'),  borderColor: PLATFORM_COLORS.tokopedia.line, borderWidth: 0, borderRadius: 3, borderSkipped: false },
            { label: 'Shopee',    data: generateChartData(days), backgroundColor: makeGradient('rgba(244,63,94,1)'),   borderColor: PLATFORM_COLORS.shopee.line,    borderWidth: 0, borderRadius: 3, borderSkipped: false },
            { label: 'TikTok',   data: generateChartData(days), backgroundColor: makeGradient('rgba(99,102,241,1)'),  borderColor: PLATFORM_COLORS.tiktok.line,    borderWidth: 0, borderRadius: 3, borderSkipped: false },
            { label: 'Lazada',   data: generateChartData(days), backgroundColor: makeGradient('rgba(251,191,36,1)'),  borderColor: PLATFORM_COLORS.lazada.line,    borderWidth: 0, borderRadius: 3, borderSkipped: false },
          ],
        },
        options: revenueChartOptions as any,
      });
    });

    return () => { chartRef.current?.destroy(); };
  }, [currentPeriod, data]);

  return (
    <div className="bg-gradient-to-br from-[#0f1320] to-[#0b0e18] rounded-[14px] border border-[rgba(255,255,255,0.065)] p-5 shadow-[0_2px_12px_rgba(0,0,0,0.4)]">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-[13px] font-bold text-[#eef0f8]">Revenue per Platform</h3>
          <p className="text-[11px] text-[#424e62] mt-0.5">{currentPeriod} terakhir · 4 platform</p>
        </div>
      </div>
      <div style={{ height: 240 }}>
        <canvas ref={canvasRef} />
      </div>
    </div>
  );
}
