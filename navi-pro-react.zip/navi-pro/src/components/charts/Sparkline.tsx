'use client';
import { useEffect, useRef } from 'react';
import { generateChartData } from '@/utils/format';
import { sparklineOptions } from '@/utils/chartConfig';

interface SparklineProps {
  color?: string;
  days?: number;
}

export function Sparkline({ color = '#6366f1', days = 14 }: SparklineProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const chartRef = useRef<any>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;
    import('chart.js/auto').then((ChartModule) => {
      const Chart = ChartModule.default;
      const ctx = canvasRef.current?.getContext('2d');
      if (!ctx) return;
      if (chartRef.current) chartRef.current.destroy();

      const gradient = ctx.createLinearGradient(0, 0, 0, 40);
      gradient.addColorStop(0, color.replace(')', ', 0.3)').replace('#', 'rgba(').replace('rgba(', 'rgba('));
      gradient.addColorStop(1, 'rgba(0,0,0,0)');

      chartRef.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: Array(days).fill(''),
          datasets: [{
            data: generateChartData(days),
            borderColor: color,
            borderWidth: 1.5,
            fill: true,
            backgroundColor: gradient,
            tension: 0.4,
            pointRadius: 0,
          }],
        },
        options: sparklineOptions as any,
      });
    });
    return () => { chartRef.current?.destroy(); };
  }, [color, days]);

  return <canvas ref={canvasRef} style={{ width: '100%', height: 44 }} />;
}
