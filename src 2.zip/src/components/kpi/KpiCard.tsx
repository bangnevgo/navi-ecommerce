'use client';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/Badge';
import { useDashboardStore } from '@/store/useDashboardStore';

interface KpiCardProps {
  label: string;
  value: string;
  sub: string;
  growth: string;
  icon: string;
  positive?: boolean;
  stagger?: number;
}

function KpiCard({ label, value, sub, growth, icon, positive = true, stagger = 0 }: KpiCardProps) {
  return (
    <Card
      className="flex-1 min-w-0 cursor-default transition-all duration-200 hover:-translate-y-0.5"
      style={{
        background: '#161b22',
        border: '1px solid #21262d',
        borderRadius: 14,
        animationDelay: `${stagger * 0.04}s`,
      }}
    >
      <CardContent className="p-[18px]">
        {/* Top row */}
        <div className="flex items-center justify-between mb-4">
          <span className="text-[11px] font-semibold tracking-wide" style={{ color: '#7d8590' }}>
            {label}
          </span>
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center text-base"
            style={{ background: '#21262d' }}
          >
            {icon}
          </div>
        </div>

        {/* Value */}
        <div
          className="text-[28px] font-bold tracking-tight leading-none mb-1"
          style={{ color: '#e6edf3', fontFamily: 'Geist Variable, system-ui' }}
        >
          {value}
        </div>

        {/* Sub + growth */}
        <div className="flex items-center justify-between mt-3 flex-wrap gap-2">
          <span className="text-[11px] truncate" style={{ color: '#484f58' }}>
            {sub}
          </span>
          <Badge variant={positive ? 'success' : 'danger'} className="text-[10px] h-[18px]">
            {positive ? '▲' : '▼'} {growth}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}

export function KpiRow() {
  const { data } = useDashboardStore();

  const cards = [
    { label: 'Total GMV',     value: `Rp ${data.gmv}`,       sub: data.gmvSub,               growth: data.gmvGrowth,     icon: '💰', positive: true  },
    { label: 'Total Pesanan', value: data.pesanan,            sub: `${data.days} hari terakhir`, growth: data.pesananGrowth, icon: '🛒', positive: true  },
    { label: 'Net Profit',    value: `Rp ${data.netProfit}`,  sub: data.profitSub,             growth: data.netGrowth,     icon: '📈', positive: true  },
    { label: 'Return Rate',   value: `${data.returnRate}%`,   sub: 'Dari total pesanan',       growth: data.returnChange,  icon: '↩️', positive: false },
  ];

  return (
    <div className="flex gap-4">
      {cards.map((c, i) => (
        <KpiCard key={c.label} {...c} stagger={i + 1} />
      ))}
    </div>
  );
}
